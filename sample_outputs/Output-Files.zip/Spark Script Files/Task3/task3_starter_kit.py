import sys
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, lit, sum as _sum, hour, avg, when, to_timestamp
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from graphframes import GraphFrame
if __name__ == "__main__":

    spark = SparkSession \
        .builder \
        .appName("ChicagoTaxiTripsAnalysis") \
        .getOrCreate()

    # Load environment variables
    s3_data_repository_bucket = os.environ.get('DATA_REPOSITORY_BUCKET', '')
    s3_endpoint_url = os.environ.get('S3_ENDPOINT_URL', '') + ':' + os.environ.get('BUCKET_PORT', '')
    s3_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID', '')
    s3_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    s3_bucket = os.environ.get('BUCKET_NAME', '')

    # Configure Hadoop for S3 access
    hadoopConf = spark.sparkContext._jsc.hadoopConfiguration()
    hadoopConf.set("fs.s3a.endpoint", s3_endpoint_url)
    hadoopConf.set("fs.s3a.access.key", s3_access_key_id)
    hadoopConf.set("fs.s3a.secret.key", s3_secret_access_key)
    hadoopConf.set("fs.s3a.path.style.access", "true")
    hadoopConf.set("fs.s3a.connection.ssl.enabled", "false")
	


#Loading the Dataset
taxi_df = spark.read.csv("s3a://data-repository-bkt/ECS765/Chicago_Taxitrips/chicago_taxi_trips.csv", header=True, inferSchema=True)

#Question1:
print(f"Total entries: {taxi_df.count()}")

#Showing the top 10 rows for verification
taxi_df.show(10, truncate=False)


#Question 2:
#Vertices (Community Areas)
vertices_df = taxi_df.select(
    col("Pickup Community Area").alias("id"),
    col("Pickup Centroid Latitude").alias("Latitude"),
    col("Pickup Centroid Longitude").alias("Longitude"),
    col("Pickup Census Tract").alias("Census_Tract")
).distinct().filter(col("id").isNotNull())

#Edges (Taxi Trips) - Ensure the src and dst columns are taken from the correct fields
edges_df = taxi_df.select(
    col("Pickup Community Area").alias("src"),      #Source community area (pickup)
    col("Dropoff Community Area").alias("dst"),     #Destination community area (dropoff)
    col("Trip Miles").alias("Trip_Miles"),
    col("Trip Seconds").alias("Trip_Seconds"),
    col("Fare").alias("Fare")
).filter(col("src").isNotNull() & col("dst").isNotNull())   #Filter to make sure no nulls in src or dst

#Displaying Edges and Vertices Samples
print("Edges Sample:")
edges_df.show(5, truncate=False)

print("Vertices Sample:")
vertices_df.show(5, truncate=False)

#Question 3:
#Building the GraphFrame
graph = GraphFrame(vertices_df, edges_df)

#Correctly rename vertex columns for joinings
src_vertices = vertices_df.withColumnRenamed("id", "src") \
    .withColumnRenamed("Latitude", "src_Latitude") \
    .withColumnRenamed("Longitude", "src_Longitude") \
    .withColumnRenamed("Census_Tract", "src_Census_Tract") 

dst_vertices = vertices_df.withColumnRenamed("id", "dst") \
    .withColumnRenamed("Latitude", "dst_Latitude") \
    .withColumnRenamed("Longitude", "dst_Longitude") \
    .withColumnRenamed("Census_Tract", "dst_Census_Tract")  

#Joining edges with enriched vertex details
enriched_graph = graph.edges \
    .join(src_vertices, on="src", how="left") \
    .join(dst_vertices, on="dst", how="left")

#Selecting necessary columns clearly
graph_data = enriched_graph.select(
    "src", "dst", "Trip_Miles", "Trip_Seconds", "Fare",
    "src_Latitude", "src_Longitude", "src_Census_Tract",
    "dst_Latitude", "dst_Longitude", "dst_Census_Tract"
)

#Displaying 10 samples
graph_data.show(10, truncate=False)


#Question4:
#Filtering edges where the source and destination are the same community area
connected_edges_df = edges_df.filter(edges_df.src == edges_df.dst)

#Counting the number of such connected edges
connected_count = connected_edges_df.count()

#Showing 10 samples from the connected edges
connected_edges_df.show(10, truncate=False)

#Displaying the total number of connected edges
print(f"Total number of connected edges (same community area): {connected_count}")


#Question5:
#Specifying the landmark community area (e.g. 49)
landmark_vertex = 49

#Running the shortest paths algorithm
shortest_paths_df = graph.shortestPaths(landmarks=[landmark_vertex])

#Extracting and formating columns explicitly
formatted_result_df = shortest_paths_df.select(
    col("id"),
    lit(landmark_vertex).alias("landmark"),  # Explicitly show the landmark vertex
    col("distances").getItem(landmark_vertex).alias("distance")  # Distance to the landmark
)

#Displaying clearly with 10 rows
formatted_result_df.show(10, truncate=False)


#Question6:
#Deduplicating vertices DataFrame explicitly to ensure uniqueness.
vertices_dedup_df = vertices_df.dropDuplicates(["id"])

#Creating the GraphFrame using the deduplicated vertices and existing edges.
taxi_graph = GraphFrame(vertices_dedup_df, edges_df)

#Run the PageRank algorithm with provided parameters.
page_rank_results = taxi_graph.pageRank(resetProbability=0.15, tol=0.01)

#Sort vertices by descending PageRank value and show top 5 clearly.
top_page_rank_vertices = page_rank_results.vertices.orderBy(col("pagerank").desc())

#Displaying top 5 vertices clearly.
top_page_rank_vertices.select("id", "pagerank").show(5, truncate=False)

#Question6: 
#Weighted Edges
#Defining vertices (unique community areas from pickups and dropoffs)
weighted_vertices_pickup = taxi_df.select(col("Pickup Community Area").alias("id")).distinct()
weighted_vertices_dropoff = taxi_df.select(col("Dropoff Community Area").alias("id")).distinct()

#Combine and remove duplicates
weighted_vertices_df = weighted_vertices_pickup.union(weighted_vertices_dropoff).distinct().filter(col("id").isNotNull())

#Define edges with weights (Trip distance as edge weight)
weighted_edges_df = taxi_df.select(
    col("Pickup Community Area").alias("src"),
    col("Dropoff Community Area").alias("dst"),
    col("Trip Miles").alias("weight")  # Trip miles is used as the weight
).filter(
    col("src").isNotNull() & col("dst").isNotNull() & (col("weight") > 0)
)

#Calculate total outgoing weights for each source clearly
weighted_total_outgoing = weighted_edges_df.groupBy("src").agg(
    _sum("weight").alias("total_weight")
)

#Normalize edge weights by dividing each edge's weight by total outgoing weight
weighted_normalized_edges = weighted_edges_df.join(weighted_total_outgoing, "src") \
    .withColumn("normalized_weight", col("weight") / col("total_weight")) \
    .select("src", "dst", "normalized_weight")  

#Create weighted GraphFrame with normalized edges
weighted_graph = GraphFrame(weighted_vertices_df, weighted_normalized_edges)

#Run PageRank algorithm using normalized edge weights
weighted_pagerank_result = weighted_graph.pageRank(resetProbability=0.15, tol=0.01)

#Display the top 5 vertices by descending PageRank value
weighted_pagerank_result.vertices.select("id", "pagerank") \
    .orderBy(col("pagerank").desc()) \
    .show(5, truncate=False)



#Question7:
#Loading DataFrame clearly
edges_df = taxi_df.select(
    col("Pickup Community Area").alias("src"),
    col("Dropoff Community Area").alias("dst"),
    col("Trip Miles").alias("Trip_Miles"),
    col("Trip Seconds").alias("Trip_Seconds"),
    col("Fare"),
    col("Trip Start Timestamp")
).filter(
    (col("src").isNotNull()) &
    (col("dst").isNotNull()) &
    (col("Fare") > 0) &
    (col("Trip_Miles") > 0) &
    (col("Trip_Seconds") > 0) &
    (col("Trip Start Timestamp").isNotNull())
)

#Fare by Distance with broader bins
fare_distance_df = edges_df \
    .withColumn("Trip Miles", 
                when(col("Trip_Miles") < 1, "<1 Mile")
                .when((col("Trip_Miles") >= 1) & (col("Trip_Miles") < 3), "1-3 Miles")
                .when((col("Trip_Miles") >= 3) & (col("Trip_Miles") < 5), "3-5 Miles")
                .when((col("Trip_Miles") >= 5) & (col("Trip_Miles") < 10), "5-10 Miles")
                .otherwise("10+ Miles")) \
    .groupBy("Trip Miles") \
    .agg(avg("Fare").alias("Avg_Fare")) \
    .orderBy("Trip Miles")

#Fare by Duration with clearer bins
fare_duration_df = edges_df \
    .withColumn("Duration_Bin", 
                when(col("Trip_Seconds") < 300, "<5 min")
                .when((col("Trip_Seconds") >= 300) & (col("Trip_Seconds") < 600), "5-10 min")
                .when((col("Trip_Seconds") >= 600) & (col("Trip_Seconds") < 1800), "10-30 min")
                .otherwise("30+ min")) \
    .groupBy("Duration_Bin") \
    .agg(avg("Fare").alias("Avg_Fare")) \
    .orderBy("Duration_Bin")

# Parse timestamp correctly and Fare by Hour
fare_timeofday_df = edges_df \
    .withColumn("parsed_time", to_timestamp(col("Trip Start Timestamp"), "MM/dd/yyyy hh:mm:ss a")) \
    .withColumn("Start_Hour", hour(col("parsed_time"))) \
    .groupBy("Start_Hour") \
    .agg(avg("Fare").alias("Avg_Fare")) \
    .orderBy("Start_Hour")

#Displaying results
print("Average Fare by Trip Distance:")
fare_distance_df.show(truncate=False)

print("Average Fare by Trip Duration:")
fare_duration_df.show(truncate=False)

print("Average Fare by Time of Day:")
fare_timeofday_df.show(24, truncate=False)

#Exporting to CSV for plotting
fare_distance_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/fare_distance.csv", header=True, mode="overwrite")
fare_duration_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/fare_duration.csv", header=True, mode="overwrite")
fare_timeofday_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/fare_timeofday.csv", header=True, mode="overwrite")










spark.stop()