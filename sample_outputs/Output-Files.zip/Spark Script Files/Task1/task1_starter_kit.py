import sys, string
import os
import socket
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import from_unixtime, date_format, col, to_date, concat_ws, sum, month, from_utc_timestamp, to_utc_timestamp, to_timestamp, count, dayofweek, hour, when, avg, expr
from pyspark.sql.types import FloatType, IntegerType 

if __name__ == "__main__":

    spark = SparkSession\
        .builder\
        .appName("twitterdata")\
        .getOrCreate()

    s3_data_repository_bucket = os.environ['DATA_REPOSITORY_BUCKET']
    s3_endpoint_url = os.environ['S3_ENDPOINT_URL']+':'+os.environ['BUCKET_PORT']
    s3_access_key_id = os.environ['AWS_ACCESS_KEY_ID']
    s3_secret_access_key = os.environ['AWS_SECRET_ACCESS_KEY']
    s3_bucket = os.environ['BUCKET_NAME']

    hadoopConf = spark.sparkContext._jsc.hadoopConfiguration()
    hadoopConf.set("fs.s3a.endpoint", s3_endpoint_url)
    hadoopConf.set("fs.s3a.access.key", s3_access_key_id)
    hadoopConf.set("fs.s3a.secret.key", s3_secret_access_key)
    hadoopConf.set("fs.s3a.path.style.access", "true")
    hadoopConf.set("fs.s3a.connection.ssl.enabled", "false")

#Loading the dataset
twitter_df = spark.read.csv("s3a://data-repository-bkt/ECS765/Twitter/twitter.csv", header=True, inferSchema=True)


#Question1:
#Printing the total no of entries in the dataset and showing some data
print("Total number of entries in Twitter Dataset: ", twitter_df.count())


#Question2: 
#Converting the timestamps to proper format and changing them to UTC timezone
twitter_df = twitter_df.withColumn(
    "timezone_str",
    when(col("timezone") == 1, "-05:00")  # Eastern Time (UTC-5)
    .when(col("timezone") == 2, "-06:00")  # Central Time (UTC-6)
    .when(col("timezone") == 3, "-07:00")  # Mountain Time (UTC-7)
    .when(col("timezone") == 4, "-08:00")  # Pacific Time (UTC-8)
    .otherwise("-05:00")  # Default Eastern Time
).withColumn(
    "local_timestamp",
    to_timestamp(col("timestamp").cast("string"), 'yyyyMMddHHmmss')
).withColumn(
    "timestamp_utc",
    expr("to_utc_timestamp(local_timestamp, timezone_str)")
).withColumn(
    "date_utc", 
    to_date(col("timestamp_utc")) 
)

filtered_df = twitter_df.filter(dayofweek('timestamp_utc').between(2, 6))
sorted_twitter_df = filtered_df.orderBy('timestamp_utc')

sorted_twitter_df.select('longitude', 'latitude', 'timestamp', 'timezone', 'timestamp_utc') \
                 .show(10, truncate=False)


#Quesiton 3
#Creating a new column combining longitude and latitude into a single location field
twitter_df = twitter_df.withColumn('location', concat_ws(',', 'longitude', 'latitude'))

#Group by location and count the number of tweets per location
location_counts = twitter_df.groupBy('location').count().withColumnRenamed('count', 'tweet_count')

#Exporting the results to CSV for visualization
location_counts.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/location_counts.csv", mode='overwrite', header=True)


#Question 4:
#Adding timezone offset 
twitter_df = twitter_df.withColumn(
    "timezone_str",
    when(col("timezone") == 1, "-05:00")
    .when(col("timezone") == 2, "-06:00")
    .when(col("timezone") == 3, "-07:00")
    .when(col("timezone") == 4, "-08:00")
    .otherwise("-05:00")
)

#Converting timestamp to a local timestamp and then to UTC timestamp
twitter_df = twitter_df.withColumn("local_timestamp", to_timestamp(col("timestamp").cast("string"), 'yyyyMMddHHmmss'))
twitter_df = twitter_df.withColumn("timestamp_utc", expr("to_utc_timestamp(local_timestamp, timezone_str)"))

#Extracting hour and day of week from UTC timestamp
processed_df = twitter_df.withColumn("hour", hour("timestamp_utc"))
                    

#Adding the time_of_day categorization
time_categories = when((col("hour") >= 5) & (col("hour") <= 11), "Morning") \
                  .when((col("hour") >= 12) & (col("hour") <= 16), "Afternoon") \
                  .when((col("hour") >= 17) & (col("hour") <= 21), "Evening") \
                  .otherwise("Night")

processed_df = processed_df.withColumn("time_of_day", time_categories)

#Showing some examples clearly
processed_df.select("timestamp_utc", "hour", "time_of_day").show(10, truncate=False)

#Counting tweets by time_of_day
final_counts_df = processed_df.groupBy("time_of_day").count()

#Custom ordering and displaying in a nice readable order
order_expr = when(col("time_of_day") == "Morning", 1) \
             .when(col("time_of_day") == "Afternoon", 2) \
             .when(col("time_of_day") == "Evening", 3) \
             .otherwise(4)

final_counts_df.orderBy(order_expr).show(truncate=False)

# Saving categorized data
final_counts_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/time_of_day_data.csv", mode="overwrite", header=True)


#Question 5 (using processed_df created above)
#Grouping the dataset by day of the week and aggregate total number of tweets per day
#Adding day_of_week column 
processed_df = processed_df.withColumn("day_of_week", date_format("timestamp_utc", "E"))

# Now Grouping by 'day_of_week'
grouped_by_day = processed_df.groupBy("day_of_week") \
                             .agg(count("*").alias("tweet_count"))

ordered_df = grouped_by_day.withColumn(
    "day_number",
    when(col("day_of_week") == "Mon", 1)
    .when(col("day_of_week") == "Tue", 2)
    .when(col("day_of_week") == "Wed", 3)
    .when(col("day_of_week") == "Thu", 4)
    .when(col("day_of_week") == "Fri", 5)
    .when(col("day_of_week") == "Sat", 6)
    .when(col("day_of_week") == "Sun", 7)
)

ordered_df = ordered_df.orderBy("day_number").drop("day_number")
ordered_df.show(10, truncate=False)

ordered_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/grouped_by_the_day.csv", mode="overwrite", header=True)

#Question 6 (using ordered_df created above):
average_tweets = ordered_df.agg(avg('tweet_count').alias('avg_tweets')).collect()[0]['avg_tweets']
unusual_days_df = ordered_df.filter(col('tweet_count') > average_tweets)

unusual_days_df.show(truncate=False)

#Question7:
#Group by location and aggregate tweet count
location_counts = twitter_df.groupBy("location") \
            .agg(count("*").alias("num_tweets")) \
            .orderBy(col("num_tweets").desc())

#Show the top 10 locations with the highest number of tweets
top_10_locations = location_counts.limit(10)

#Showing the results
top_10_locations.show(truncate=False)


spark.stop
