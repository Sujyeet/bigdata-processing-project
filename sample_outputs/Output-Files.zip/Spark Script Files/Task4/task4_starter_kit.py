import sys, string
import os
import socket
import time
import operator
import boto3
import json
from pyspark.sql import Row, SparkSession
from pyspark.sql.streaming import DataStreamWriter, DataStreamReader
from pyspark.sql.functions import explode, split, window, col, count, regexp_extract, to_timestamp
from pyspark.sql.types import IntegerType, DateType, StringType, StructType
from pyspark.sql.functions import sum, avg, max, when
from datetime import datetime

if __name__ == "__main__":
    spark = SparkSession \
        .builder \
        .appName("HDFSLogSparkStreaming") \
        .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    # Host and port from environment variables
    host = os.getenv("STREAMING_SERVER_HDFS", "default_host")
    port = int(os.getenv("STREAMING_SERVER_HDFS_PORT", "default_port"))


#Loading data from socket
raw_df = spark.readStream.format("socket") \
            .option("host", host) \
            .option("port", port) \
            .load()

#Question1:
#Defining the schema explicitly
log_schema = StructType() \
    .add("Timestamp", StringType()) \
    .add("LogLevel", StringType()) \
    .add("Component", StringType()) \
    .add("BlockID", StringType()) \
    .add("Source", StringType()) \
    .add("Destination", StringType()) \
    .add("Size", StringType()) \
    .add("Message", StringType())



#Extracting the fields from logs using regex
logs_df = raw_df.select(
    regexp_extract('value', r'^(\S+\s+\S+)', 1).alias('Timestamp'),
    regexp_extract('value', r'\s(INFO|WARN|ERROR)\s', 1).alias('LogLevel'),
    regexp_extract('value', r'\s([a-zA-Z0-9\.\$\-]+):', 1).alias('Component'),
    regexp_extract('value', r'(blk_[\-\d]+)', 1).alias('BlockID'),
    regexp_extract('value', r'src:\s(\S+)', 1).alias('Source'),
    regexp_extract('value', r'dest:\s(\S+)', 1).alias('Destination'),
    regexp_extract('value', r'size\s(\d+)', 1).alias('Size'),
    regexp_extract('value', r':\s(.+)', 1).alias('Message')
    )

#Console output of extracted structured fields
query = logs_df.writeStream \
                .format("console") \
                .outputMode("append") \
                .option("truncate", False) \
                .start()

#Process time
query.awaitTermination(10)



#Question2:
#Fixing timestamp format and watermark
logs_df = logs_df.withColumn(
    "Timestamp",
    to_timestamp(col("Timestamp"), "yyMMdd HHmmss")
)

#Adding watermark (5-second delay)
watermarked_df = logs_df.withWatermark("Timestamp", "5 seconds")

  
#Question3: 
#Displaying the Data with Batch Numbers
query3 = logs_df.writeStream \
    .format("console") \
    .outputMode("append") \
    .option("truncate", False) \
    .start()

#Process time
query3.awaitTermination(60)


# Question 4: Fixed DataNode analysis using watermarked DF
datanode_df = watermarked_df.filter(col("Component").contains("DataNode"))

aggregated_datanode_df = datanode_df.groupBy(
    window(col("Timestamp"), "60 seconds", "30 seconds")
).agg(count("*").alias("datanode_count"))

query4 = aggregated_datanode_df.writeStream \
    .format("console") \
    .outputMode("update") \
    .option("truncate", False) \
    .start()

#Process time
query4.awaitTermination(120)


#Question5:
#Converting the size column to integer 
logs_df = logs_df.withColumn("Size", col("Size").cast("int"))

#Extracting IP address from the Source column.
logs_df = logs_df.withColumn("hostname", regexp_extract(col("Source"), r'(\d+\.\d+\.\d+\.\d+)', 1))

#Group by hostname and aggregate the sum of bytes transferred
aggregated_bytes_df = logs_df.groupBy("hostname") \
    .agg(sum("Size").alias("total bytes")) \
    .orderBy(col("total bytes").desc())

#Output results to console without truncation
query5_filtered = aggregated_bytes_df.writeStream \
    .format("console") \
    .outputMode("complete") \
    .option("truncate", False) \
    .start()

query5_filtered.awaitTermination(240)


#Question6:
#Filtering the log data to include only INFO entries with a block ID that contains blk
filtered_logs = logs_df.filter(
    (col("LogLevel") == "INFO") & 
    (col("BlockID").contains("blk"))
)

#Grouping by hostname and count the number of such entries for each host
grouped_by_hostname = filtered_logs.groupBy("hostname") \
    .agg(count("*").alias("entry_count"))

#Outputting the aggregated results to the console
#Triggering the query every 15 seconds
query6 = grouped_by_hostname.writeStream \
    .trigger(processingTime="15 seconds") \
    .format("console") \
    .outputMode("complete") \
    .option("truncate", False) \
    .start()

#Process time
query6.awaitTermination(240)



query.stop()
query1.stop()
query2.stop()
query3.stop()
query4.stop()
query5.stop()
query6.stop()


spark.stop()





















