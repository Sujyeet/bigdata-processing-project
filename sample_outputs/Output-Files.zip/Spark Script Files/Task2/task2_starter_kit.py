import sys
import os
import socket
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import from_unixtime, date_format, col, to_date, concat_ws, sum, month, to_timestamp, count, length, when, dayofweek, to_csv, year, explode, split, avg
from pyspark.sql.types import FloatType, IntegerType

if __name__ == "__main__":

    spark = SparkSession \
        .builder \
        .appName("movieratings") \
        .getOrCreate()

    # Load environment variables
    s3_data_repository_bucket = os.environ.get('DATA_REPOSITORY_BUCKET', '')
    s3_endpoint_url = os.environ.get('S3_ENDPOINT_URL', '') + ':' + os.environ.get('BUCKET_PORT', '')
    s3_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID', '')
    s3_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    s3_bucket = os.environ.get('BUCKET_NAME', '')

    # Configure Hadoop for S3 access
    hadoopConf = spark.sparkContext._jsc.hadoopConfiguration()
    hadoopConf.set("fs.s3a.endpoint", s3_endpoint_url)
    hadoopConf.set("fs.s3a.access.key", s3_access_key_id)
    hadoopConf.set("fs.s3a.secret.key", s3_secret_access_key)
    hadoopConf.set("fs.s3a.path.style.access", "true")
    hadoopConf.set("fs.s3a.connection.ssl.enabled", "false")

#Loading the datasets
ratings_df = spark.read.csv("s3a://data-repository-bkt/ECS765/MovieLens/ratings.csv", header=True, inferSchema=True)

#Question1:
#Displaying Unique Users
unique_users = ratings_df.select("userId").distinct().count()
print(f"Number of unique users: {unique_users}")


#Question2:
#Converting the timestamp to "YYYY-MM-DD" format
ratings_df = ratings_df.withColumn("timestamp", from_unixtime(col("timestamp"), "yyyy-MM-dd"))

#Sorting the data by the date
sorted_ratings_df = ratings_df.orderBy("timestamp")

#Showing the top results
sorted_ratings_df.show(10, truncate=False)


#Question3: 
#Categorizing the ratings into Low, Medium, and High
rating_cat_df = ratings_df.withColumn(
    "rating_category",
    when((col("rating") >= 1.0) & (col("rating") <= 2.0), "Low")
    .when((col("rating") >= 3.0) & (col("rating") <= 4.0), "Medium")
    .when(col("rating") == 5.0, "High")
)

#Remove null categories
rating_cat_df = rating_cat_df.filter(col("rating_category").isNotNull())

#Group by rating category and count ratings
rating_cat_df = rating_cat_df.groupBy("rating_category").agg(count("*").alias("rating_count"))

#Displaying the sorted dataframe
rating_cat_df.show(truncate=False)

#Exporting the sorted result to CSV for visualizatiob
rating_cat_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/rating_distribution.csv", mode="overwrite", header=True)


#Questoin4:
#Extracting the year and month clearly
ratings_df_filtered = ratings_df.withColumn("year", year("timestamp")) \
                                .withColumn("month", month("timestamp"))

#Categorizing into "Early Year" (Jan - Jun) and "Late Year" (Jul - Dec) clearly
ratings_df_filtered = ratings_df_filtered.withColumn(
    "rating_year_category",
    when(col("month").between(1, 6), "Early Year").otherwise("Late Year")
)

#Showing first 10 rows clearly
ratings_df_filtered.select("timestamp", "year", "month", "rating_year_category").show(10, truncate=False)

#Aggregating tweet counts clearly in PySpark syntax
ratings_count = ratings_df_filtered.groupBy('rating_year_category').count()

#Renaming count column to rating_count clearly
ratings_count = ratings_count.withColumnRenamed('count', 'rating_count')

#Exporting results to CSV clearly (fixing typo clearly)
ratings_count.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/rating_year_category.csv", mode="overwrite", header=True)


#Question5: 
#Loading the movies dataset
movies_df = spark.read.csv("s3a://data-repository-bkt/ECS765/MovieLens/movies.csv", header=True, inferSchema=True)

#Joining ratings_df with movies_df on 'movieId'
ratings_movies_df = ratings_df.join(movies_df, "movieId", "inner")

#Extracting individual genres from genres column
ratings_movies_df = ratings_movies_df.withColumn("genre", explode(split(col("genres"), "\\|")))

#List of valid genres provided in the given question
valid_genres = ["Action", "Adventure", "Animation", "Children", "Comedy", 
                "Crime", "Documentary", "Drama", "Fantasy", "Film-Noir",
                "Horror", "Musical", "Mystery", "Romance", "Sci-Fi",
                "Thriller", "War", "Western"]

#Filtering out invalid genres
filtered_genres_df = ratings_movies_df.filter(col("genre").isin(valid_genres))

#Grouping the dataset by genre and counting the number of ratings per genre
genre_rating_counts_df = filtered_genres_df.groupBy("genre").agg(count("*").alias("rating_count"))

#Displaying the sorted results clearly
genre_rating_counts_df.orderBy(col("rating_count").desc()).show(truncate=False)

#Exporting the results for visualization locally
genre_rating_counts_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/genre_rating_counts.csv", mode="overwrite", header=True)

#Question6:
#Extracting the year from the timestamp
ratings_df = ratings_df.withColumn("year", year("timestamp"))

#Grouping by year and aggregate the count of ratings
ratings_per_year_df = ratings_df.groupBy("year").agg(count("*").alias("total_ratings"))

#Showing 10 rows of the aggregated results
ratings_per_year_df.show(10, truncate=False)

#Exporting the result for visualization
ratings_per_year_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/ratings_per_year.csv", mode="overwrite", header=True)


#Question7:
#Calculateing average rating per movie
avg_ratings_df = ratings_df.groupBy("movieId")\
                           .agg(avg("rating").alias("avg_rating"))

#Joining with movies to get titles and genres
top_movies_df = avg_ratings_df.join(movies_df, "movieId")

#Sorting by average rating descending and take top 10
top_10_movies_df = top_movies_df.orderBy(col("avg_rating").desc()).limit(10)

#Displaying the top 10 movies
top_10_movies_df.select("movieId", "avg_rating", "title", "genres").show(truncate=False)

#Exporting results to CSV for local visualization if needed
top_10_movies_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/top_10_movies.csv", mode="overwrite", header=True)


#Questipm8:
#Counting the number of ratings per user
user_ratings_df = ratings_df.groupBy("userId") \
                            .agg(count("*").alias("rating_count"))

#Categorizing users into "Frequent Raters" and "Infrequent Raters"
user_ratings_df = user_ratings_df.withColumn(
    "rater_category",
    when(col("rating_count") > 50, "Frequent Raters").otherwise("Infrequent Raters")
)

#Finding the top 10 users with highest no of ratings
top_10_users_df = user_ratings_df.orderBy(col("rating_count").desc()).limit(10)

#Displaying the top 10 results
top_10_users_df.show(truncate=False)

#Exporting the categorized data for visualization 
user_ratings_df.coalesce(1).write.csv(f"s3a://{s3_bucket}/output/user_analysis.csv", mode="overwrite", header=True)



















spark.stop